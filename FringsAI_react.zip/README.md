##React Responsive Navbar built by Pritesh

#To run this locally, 
1.) extract this zip file and open folder in vs code
2.) Run "npm install" to install node_modules and dependancies
3.) Run "npm start" to run the app on  localhost:3000

##Moreover to see screenshots, find them in this folder with following names:- close_mobile.png, desktop.png and hamburger_open_mobile.png

## Thanks and Regards